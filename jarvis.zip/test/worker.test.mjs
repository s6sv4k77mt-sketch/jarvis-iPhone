// Test del backend senza rete: simuliamo Gemini, Open-Meteo, Google Notizie e Wikipedia.
// Si lanciano con:  npm test
import { test } from "node:test";
import assert from "node:assert/strict";
import worker from "../src/index.js";
import { runTool } from "../src/tools.js";

const ENV = {
  GEMINI_API_KEY: "AIza-test",
  JARVIS_TOKEN: "segreto-di-test",
  MODEL: "gemini-3.8-flash",
  TIMEZONE: "Europe/Rome",
  OWNER_NAME: "Tester",
};

const call = (body, token = ENV.JARVIS_TOKEN, env = ENV) =>
  worker.fetch(
    new Request("https://jarvis.test/api/chat", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        ...(token ? { authorization: `Bearer ${token}` } : {}),
      },
      body: typeof body === "string" ? body : JSON.stringify(body),
    }),
    env
  );

const jsonRes = (data, status = 200) =>
  new Response(JSON.stringify(data), { status, headers: { "content-type": "application/json" } });

const geminiText = (text) => ({
  candidates: [{ content: { role: "model", parts: [{ text }] }, finishReason: "STOP" }],
});

function withFetch(handler, fn) {
  const original = globalThis.fetch;
  globalThis.fetch = handler;
  return Promise.resolve(fn()).finally(() => (globalThis.fetch = original));
}

test("health check", async () => {
  const res = await worker.fetch(new Request("https://jarvis.test/api/health"), ENV);
  assert.equal(res.status, 200);
  assert.deepEqual(await res.json(), { ok: true });
});

test("senza token -> 401", async () => {
  assert.equal((await call({ message: "ciao" }, null)).status, 401);
});

test("token sbagliato -> 401", async () => {
  assert.equal((await call({ message: "ciao" }, "sbagliato")).status, 401);
});

test("server senza secret -> 500 con messaggio chiaro", async () => {
  const res = await call({ message: "ciao" }, "x", { ...ENV, GEMINI_API_KEY: undefined });
  assert.equal(res.status, 500);
  assert.match((await res.json()).error, /GEMINI_API_KEY/);
});

test("messaggio vuoto -> 400", async () => {
  assert.equal((await call({ message: "   " })).status, 400);
});

test("JSON non valido -> 400", async () => {
  assert.equal((await call("{non json")).status, 400);
});

test("GET su /api/chat -> 405", async () => {
  const res = await worker.fetch(new Request("https://jarvis.test/api/chat"), ENV);
  assert.equal(res.status, 405);
});

test("risposta semplice e richiesta a Gemini ben formata", async () => {
  let seen;
  await withFetch(
    async (url, init) => {
      seen = { url: String(url), init, body: JSON.parse(init.body) };
      return jsonRes(geminiText("Buongiorno."));
    },
    async () => {
      const res = await call({ message: "ciao" });
      assert.equal(res.status, 200);
      assert.deepEqual(await res.json(), { reply: "Buongiorno." });
    }
  );

  assert.equal(
    seen.url,
    "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent"
  );
  assert.ok(!seen.url.includes("AIza"), "la chiave non deve stare nell'URL");
  assert.equal(seen.init.headers["x-goog-api-key"], "AIza-test");
  assert.match(seen.body.systemInstruction.parts[0].text, /Tester/);
  assert.deepEqual(seen.body.contents, [{ role: "user", parts: [{ text: "ciao" }] }]);
  assert.equal(seen.body.generationConfig.maxOutputTokens, 2048);
  assert.equal(seen.body.generationConfig.thinkingConfig, undefined);

  const decls = seen.body.tools[0].functionDeclarations;
  assert.ok(decls.some((d) => d.name === "get_weather"));
  assert.ok(decls.some((d) => d.name === "get_news"));
  // senza KV le note non devono essere esposte
  assert.ok(!decls.some((d) => d.name === "save_note"));
  // nessuna dichiarazione con "properties" vuote o "required" vuoto (Gemini li rifiuta)
  for (const d of decls) {
    if (d.parameters) {
      assert.ok(Object.keys(d.parameters.properties).length > 0, d.name);
      assert.ok(d.parameters.required === undefined || d.parameters.required.length > 0, d.name);
    }
  }
});

test("con il KV le note compaiono e list_notes non ha parametri", async () => {
  let body;
  await withFetch(
    async (url, init) => {
      body = JSON.parse(init.body);
      return jsonRes(geminiText("ok"));
    },
    async () => {
      await call({ message: "ciao" }, ENV.JARVIS_TOKEN, { ...ENV, NOTES: {} });
    }
  );
  const decls = body.tools[0].functionDeclarations;
  const list = decls.find((d) => d.name === "list_notes");
  assert.ok(list);
  assert.equal(list.parameters, undefined);
  assert.ok(decls.some((d) => d.name === "save_note"));
});

test("THINKING_LEVEL viene passato solo se impostato", async () => {
  let body;
  await withFetch(
    async (url, init) => {
      body = JSON.parse(init.body);
      return jsonRes(geminiText("ok"));
    },
    async () => {
      await call({ message: "ciao" }, ENV.JARVIS_TOKEN, { ...ENV, THINKING_LEVEL: "low" });
    }
  );
  assert.equal(body.generationConfig.thinkingConfig.thinkingLevel, "low");
});

test("ciclo degli strumenti: Gemini chiede il meteo, Jarvis risponde", async () => {
  let geminiCalls = 0;
  const modelParts = [
    {
      functionCall: { id: "call_1", name: "get_weather", args: { city: "Milano", days: 2 } },
      thoughtSignature: "FIRMA-SEGRETA",
    },
  ];

  await withFetch(
    async (url, init) => {
      const u = String(url);
      if (u.includes("geocoding-api.open-meteo.com")) {
        return jsonRes({ results: [{ name: "Milano", country: "Italia", latitude: 45.46, longitude: 9.19 }] });
      }
      if (u.includes("api.open-meteo.com")) {
        return jsonRes({
          current: { temperature_2m: 12.4, apparent_temperature: 11, relative_humidity_2m: 70, weather_code: 3, wind_speed_10m: 6 },
          daily: {
            time: ["2026-11-04", "2026-11-05"],
            weather_code: [3, 61],
            temperature_2m_max: [14, 13],
            temperature_2m_min: [8, 9],
            precipitation_probability_max: [10, 80],
          },
        });
      }

      geminiCalls++;
      const body = JSON.parse(init.body);
      if (geminiCalls === 1) {
        return jsonRes({ candidates: [{ content: { role: "model", parts: modelParts }, finishReason: "STOP" }] });
      }

      // Secondo giro: il messaggio del modello deve tornare identico (con la firma)
      const [first, modelMsg, toolMsg] = body.contents;
      assert.equal(first.role, "user");
      assert.equal(modelMsg.role, "model");
      assert.equal(modelMsg.parts[0].thoughtSignature, "FIRMA-SEGRETA");
      assert.equal(toolMsg.role, "user");
      const fr = toolMsg.parts[0].functionResponse;
      assert.equal(fr.name, "get_weather");
      assert.equal(fr.id, "call_1");
      assert.match(fr.response.result, /Milano/);
      return jsonRes(geminiText("A Milano è coperto, 12 gradi."));
    },
    async () => {
      const res = await call({ message: "che tempo fa a Milano?" });
      assert.equal(res.status, 200);
      assert.equal((await res.json()).reply, "A Milano è coperto, 12 gradi.");
    }
  );
  assert.equal(geminiCalls, 2);
});

test("errore di uno strumento: Gemini riceve { error } e può comunque rispondere", async () => {
  let secondBody;
  let n = 0;
  await withFetch(
    async (url, init) => {
      if (String(url).includes("geocoding-api")) return jsonRes({ results: [] });
      n++;
      if (n === 1) {
        return jsonRes({
          candidates: [{ content: { role: "model", parts: [{ functionCall: { name: "get_weather", args: { city: "Xyzzy" } } }] } }],
        });
      }
      secondBody = JSON.parse(init.body);
      return jsonRes(geminiText("Non trovo quella città."));
    },
    async () => {
      const res = await call({ message: "meteo a Xyzzy" });
      assert.equal((await res.json()).reply, "Non trovo quella città.");
    }
  );
  const fr = secondBody.contents.at(-1).parts[0].functionResponse;
  assert.match(fr.response.error, /Città non trovata/);
  assert.equal(fr.id, undefined);
});

test("errori di Gemini -> 502 con suggerimento utile", async () => {
  const cases = [
    [429, /quota gratuita/],
    [403, /GEMINI_API_KEY/],
    [404, /MODEL/],
  ];
  for (const [status, pattern] of cases) {
    await withFetch(
      async () => jsonRes({ error: { message: "boom" } }, status),
      async () => {
        const res = await call({ message: "ciao" });
        assert.equal(res.status, 502);
        assert.match((await res.json()).error, pattern);
      }
    );
  }
});

test("richiesta bloccata dai filtri o risposta vuota: messaggio gentile, non errore", async () => {
  await withFetch(
    async () => jsonRes({ promptFeedback: { blockReason: "SAFETY" } }),
    async () => {
      const res = await call({ message: "ciao" });
      assert.equal(res.status, 200);
      assert.match((await res.json()).reply, /bloccata/);
    }
  );
  await withFetch(
    async () => jsonRes({ candidates: [{ content: { role: "model", parts: [] }, finishReason: "MAX_TOKENS" }] }),
    async () => {
      const res = await call({ message: "ciao" });
      assert.match((await res.json()).reply, /MAX_TOKENS/);
    }
  );
});

test("i pensieri interni (thought) non finiscono nella risposta", async () => {
  await withFetch(
    async () =>
      jsonRes({
        candidates: [
          { content: { role: "model", parts: [{ text: "ragiono...", thought: true }, { text: "Ciao!" }] } },
        ],
      }),
    async () => {
      assert.equal((await (await call({ message: "ciao" })).json()).reply, "Ciao!");
    }
  );
});

test("storico: parte sempre da un messaggio utente, 'assistant' diventa 'model'", async () => {
  let body;
  await withFetch(
    async (url, init) => {
      body = JSON.parse(init.body);
      return jsonRes(geminiText("ok"));
    },
    async () => {
      await call({
        messages: [
          { role: "assistant", content: "orfano" },
          { role: "user", content: "uno" },
          { role: "assistant", content: "due" },
          { role: "user", content: "tre" },
        ],
      });
    }
  );
  assert.deepEqual(
    body.contents.map((c) => c.role),
    ["user", "model", "user"]
  );
  assert.equal(body.contents.at(-1).parts[0].text, "tre");
});

test("strumenti: ora, strumento sconosciuto, note senza KV", async () => {
  const t = await runTool("get_current_time", { timezone: "Europe/Rome" }, ENV);
  assert.equal(t.isError, false);
  assert.match(t.content, /Europe\/Rome/);

  assert.equal((await runTool("get_current_time", { timezone: "Marte/Olympus" }, ENV)).isError, true);
  assert.equal((await runTool("non_esiste", {}, ENV)).isError, true);
  assert.equal((await runTool("save_note", { text: "x" }, ENV)).isError, true);
});

test("strumenti: notizie (RSS di Google Notizie)", async () => {
  const rss = `<?xml version="1.0"?><rss><channel><title>Google Notizie</title>
    <item><title>Governo &amp; Parlamento: intesa sul bilancio - ANSA</title></item>
    <item><title><![CDATA[Roma, derby alle 18 - Corriere]]></title></item>
  </channel></rss>`;
  let requested;
  await withFetch(
    async (url) => {
      requested = String(url);
      return new Response(rss, { status: 200 });
    },
    async () => {
      const out = await runTool("get_news", { topic: "calcio" }, ENV);
      assert.equal(out.isError, false);
      assert.match(out.content, /1\. Governo & Parlamento: intesa sul bilancio - ANSA/);
      assert.match(out.content, /2\. Roma, derby alle 18 - Corriere/);
    }
  );
  assert.match(requested, /news\.google\.com\/rss\/search\?q=calcio&hl=it&gl=IT/);
});

test("strumenti: Wikipedia", async () => {
  await withFetch(
    async (url, init) => {
      assert.match(String(url), /it\.wikipedia\.org/);
      assert.ok(init.headers["user-agent"]);
      return jsonRes({ query: { pages: { 123: { title: "Galileo Galilei", extract: "Fisico e astronomo pisano." } } } });
    },
    async () => {
      const out = await runTool("wikipedia_summary", { query: "Galileo" }, ENV);
      assert.equal(out.isError, false);
      assert.equal(out.content, "Galileo Galilei: Fisico e astronomo pisano.");
    }
  );
  await withFetch(
    async () => jsonRes({ batchcomplete: "" }),
    async () => {
      assert.equal((await runTool("wikipedia_summary", { query: "zzz" }, ENV)).isError, true);
    }
  );
});

test("strumenti: note con KV finto", async () => {
  const data = new Map();
  const NOTES = {
    put: async (k, v) => void data.set(k, v),
    get: async (k) => data.get(k) ?? null,
    delete: async (k) => void data.delete(k),
    list: async ({ prefix }) => ({ keys: [...data.keys()].filter((k) => k.startsWith(prefix)).map((name) => ({ name })) }),
  };
  const env = { ...ENV, NOTES };

  const saved = await runTool("save_note", { text: "comprare il latte" }, env);
  assert.equal(saved.isError, false);
  const id = saved.content.match(/id (\w+)/)[1];

  const list = await runTool("list_notes", {}, env);
  assert.match(list.content, /comprare il latte/);
  assert.ok(list.content.includes(id));

  await runTool("delete_note", { id }, env);
  assert.match((await runTool("list_notes", {}, env)).content, /Non ci sono note/);
});
