# 🤖 JARVIS: il tuo assistente personale su iPhone (100% gratis)

Un assistente basato su **Google Gemini** (piano gratuito) che parla italiano, ti ascolta e ti risponde a voce, conosce meteo, notizie e Wikipedia, prende appunti, e vive in un repo GitHub tuo che si aggiorna da solo a ogni modifica.

```
┌────────────┐  voce/testo   ┌──────────────────────┐   API    ┌───────────┐
│  iPhone    │ ───────────►  │  Cloudflare Worker   │ ───────► │  Gemini   │
│  • App PWA │  (HTTPS +     │  (src/index.js)      │ ◄─────── │  (Google) │
│  • Siri    │   token)      │  • controlla il token│          └───────────┘
│    Comando │ ◄───────────  │  • system prompt     │   tool   ┌───────────┐
└────────────┘   risposta    │  • strumenti: meteo, │ ───────► │ Open-Meteo│
                             │    ora, notizie,     │          │ G. Notizie│
                             │    Wikipedia, note   │          │ Wikipedia │
                             └──────────▲───────────┘          │ KV (note) │
                                        │ deploy automatico    └───────────┘
                             ┌──────────┴───────────┐
                             │  GitHub (questo repo)│
                             │  + GitHub Actions    │
                             └──────────────────────┘
```

**Perché questa architettura:** la chiave di Gemini resta *solo* sul server (mai nell'app sul telefono), l'hosting è gratuito, e per aggiornare Jarvis basta fare un commit.

**Tempo:** circa 45 minuti la prima volta. **Costi:** zero. GitHub, Cloudflare e Gemini hanno piani gratuiti e **non serve nessuna carta di credito**. Leggi però la sezione [Sicurezza, privacy e limiti](#10-sicurezza-privacy-e-limiti): il piano gratuito ha delle regole sui dati che è bene conoscere.

---

## Indice

0. [Cosa ti serve](#0-cosa-ti-serve)
1. [Account e chiavi](#1-account-e-chiavi)
2. [Metti il codice su GitHub](#2-metti-il-codice-su-github)
3. [Collega GitHub a Cloudflare](#3-collega-github-a-cloudflare-i-secret)
4. [Primo deploy](#4-primo-deploy)
5. [Installa l'app sull'iPhone](#5-installa-lapp-sulliphone)
6. [Attivazione a voce con Siri](#6-attivazione-a-voce-con-siri)
7. [Personalizza Jarvis](#7-personalizza-jarvis)
8. [Fase 4: note persistenti (opzionale)](#8-fase-4-note-persistenti-opzionale)
9. [Fase 5: briefing mattutino (opzionale)](#9-fase-5-briefing-mattutino-opzionale)
10. [Sicurezza, privacy e limiti](#10-sicurezza-privacy-e-limiti)
11. [Problemi comuni](#11-problemi-comuni)
12. [Idee per andare oltre](#12-idee-per-andare-oltre)
13. [Mappa dei file](#13-mappa-dei-file)

---

## 0. Cosa ti serve

- iPhone con Safari
- Un indirizzo email e un **account Google** (per la chiave di Gemini)
- Un posto dove tenere appunti per 4 valori segreti (l'app **Note** va bene, poi cancellali)

I 4 valori che raccoglierai:

| Nome | Cos'è | Dove lo ottieni |
|---|---|---|
| `GEMINI_API_KEY` | chiave gratuita per usare Gemini | aistudio.google.com |
| `JARVIS_TOKEN` | la "password" di Jarvis, la scegli tu | la generi tu (passo 1.4) |
| `CLOUDFLARE_API_TOKEN` | permette a GitHub di pubblicare | dashboard Cloudflare |
| `CLOUDFLARE_ACCOUNT_ID` | identifica il tuo account Cloudflare | dashboard Cloudflare |

---

## 1. Account e chiavi

### 1.1 GitHub
Hai già l'account? Salta. Altrimenti: **github.com → Sign up**.

### 1.2 Google AI Studio (la chiave di Gemini)
1. Da Safari vai su **aistudio.google.com** e accedi con il tuo account Google (accetta i termini se richiesto).
2. Tocca **Get API key** (a sinistra, oppure nel menu ☰) → **Create API key**.
3. Se ti chiede un progetto, scegli **Create API key in new project**.
4. **Copia la chiave** (inizia con `AIza...`) e incollala nelle Note come `GEMINI_API_KEY`.

> ⚠️ **Non attivare la fatturazione** (Billing) sul progetto: finché non lo fai resti nel piano gratuito e non puoi spendere nulla. Attivarla sposterebbe il progetto sul livello a pagamento.
>
> I limiti esatti (richieste al minuto e al giorno) li vedi nella pagina dei limiti di AI Studio per il tuo progetto: cambiano nel tempo, ma per uso personale sono più che sufficienti.

### 1.3 Cloudflare (hosting gratuito)
1. Vai su **dash.cloudflare.com** e registrati (piano **Free**). Non serve un dominio né una carta.
2. **Account ID:** una volta dentro, guarda l'indirizzo in Safari: è `dash.cloudflare.com/` seguito da una stringa di 32 caratteri. Quella è l'ID. Copiala come `CLOUDFLARE_ACCOUNT_ID`. (In alternativa lo trovi in *Workers & Pages → Overview*.)
3. **Sottodominio workers.dev:** vai su **Workers & Pages**. Se ti chiede di scegliere un sottodominio (es. `mario-rossi`), sceglilo: i tuoi indirizzi saranno `https://jarvis.mario-rossi.workers.dev`. *Questo passaggio va fatto adesso, altrimenti il primo deploy fallisce.*
4. **API token:** tocca l'icona del profilo in alto a destra → **My Profile → API Tokens → Create Token**:
   - Scegli il modello **Edit Cloudflare Workers** → **Use template**
   - *Account Resources:* il tuo account · *Zone Resources:* All zones (se richiesto)
   - **Continue to summary → Create Token**
   - **Copia il token** subito (non lo rivedrai) → `CLOUDFLARE_API_TOKEN`

### 1.4 Il tuo JARVIS_TOKEN
È la password che protegge Jarvis: chi la conosce può usare la tua quota di Gemini. Deve essere **lunga e casuale**, almeno 32 caratteri. Il modo più semplice su iPhone: app **Password** (o Impostazioni → Password) → nuova password → **Suggerisci password sicura**, oppure scrivi tu 40 caratteri a caso. Salvala come `JARVIS_TOKEN`.

> Evita simboli strani come `"`, `\` o spazi: li rendono scomodi da incollare nei Comandi di Siri. Lettere e numeri vanno benissimo.

---

## 2. Metti il codice su GitHub

### 2.1 Crea il repository
1. github.com → **+** → **New repository**
2. Nome: `jarvis` · visibilità: **Private** (consigliato) · spunta **Add a README file** (serve perché GitHub permetta di aprire l'editor nel browser; lo sovrascriveremo)
3. **Create repository**

### 2.2 Carica i file (scegli UNA strada)

#### Strada A: solo da iPhone, con Codespaces (consigliata)
1. Salva `jarvis.zip` nell'app **File** dell'iPhone (dalla chat: tocca il file → **Salva su File**). **Non scompattarlo**: lo carichiamo intero.
2. Nel tuo repo su github.com (da Safari, se serve attiva "Sito desktop"): **Code → Codespaces → Create codespace on main**. Si apre VS Code nel browser; ruota l'iPhone in orizzontale se ti è più comodo.
3. Nel pannello file a sinistra: tieni premuto/tasto destro nello spazio vuoto → **Upload…** → scegli `jarvis.zip` dall'app File.
4. Apri il **terminale** (menu ☰ → Terminal → New Terminal) ed esegui:
   ```bash
   unzip -o jarvis.zip && rm jarvis.zip
   git add -A
   git commit -m "Primo Jarvis"
   git push origin HEAD:main
   ```
5. Fatto. Puoi chiudere il Codespace (si ferma da solo); il piano gratuito include diverse ore al mese.

#### Strada B: da un computer
```bash
git clone https://github.com/TUO-UTENTE/jarvis.git
cd jarvis
unzip -o ../jarvis.zip
git add -A
git commit -m "Primo Jarvis"
git push
```

#### Strada C: file per file dal sito GitHub
Funziona ma è lunga (circa 15 file). Nel repo: **Add file → Create new file**, nel campo nome scrivi il percorso completo (es. `src/index.js`: le cartelle si creano da sole digitando `/`), incolla il contenuto, **Commit**. Ripeti per ogni file (le icone PNG non si possono incollare: usa **Upload files** per quelle).

> ⚠️ I file che iniziano con il punto (`.github/workflows/deploy.yml`, `.gitignore`) sono **obbligatori**: sono invisibili in alcune app File. Con le strade A e B arrivano da soli.

---

## 3. Collega GitHub a Cloudflare (i secret)

I "secret" sono caselle cifrate dove GitHub conserva le tue chiavi. Non finiscono mai nel codice.

Nel repo: **Settings → Secrets and variables → Actions → New repository secret**. Creane **4**, con questi nomi **esatti** (maiuscole comprese):

| Name | Secret (il valore) |
|---|---|
| `GEMINI_API_KEY` | la chiave `AIza...` |
| `JARVIS_TOKEN` | la tua password lunga |
| `CLOUDFLARE_API_TOKEN` | il token di Cloudflare |
| `CLOUDFLARE_ACCOUNT_ID` | l'ID di 32 caratteri |

Dopo averli salvati, cancella gli appunti con le chiavi.

---

## 4. Primo deploy

1. Nel repo apri la scheda **Actions**. Se ti dice che i workflow sono disabilitati, tocca **I understand my workflows, go ahead and enable them**.
2. Scegli **Deploy Jarvis** → **Run workflow** → **Run workflow** (il deploy parte anche da solo a ogni push su `main`).
3. Aspetta 1-2 minuti: deve diventare **verde ✅**. I passi sono: installa → test → deploy.
4. Trova l'indirizzo: nel log del passo di deploy compare `https://jarvis.TUO-SUBDOMAIN.workers.dev`; lo vedi anche in Cloudflare → **Workers & Pages → jarvis**.
5. **Test rapido:** apri in Safari `https://jarvis.TUO-SUBDOMAIN.workers.dev/api/health`. Devi vedere `{"ok":true}`.

Da qui in poi ogni modifica ai file su GitHub aggiorna Jarvis in ~1 minuto.

---

## 5. Installa l'app sull'iPhone

1. In **Safari** apri `https://jarvis.TUO-SUBDOMAIN.workers.dev`
2. Tocca **Condividi** (quadrato con la freccia) → **Aggiungi alla schermata Home** → **Aggiungi**
3. Apri **Jarvis** dalla schermata Home (si apre a schermo intero)
4. Tocca ⚙︎ → incolla il **JARVIS_TOKEN** → **Salva**. *(L'app installata ha una memoria separata da Safari: il token va inserito qui anche se lo avevi messo in Safari.)*
5. Scrivi "Che ore sono?" e prova, poi tocca il **microfono** e parla.

**Voce di Jarvis:** per una voce molto più naturale scarica quella migliorata: *Impostazioni → Accessibilità → Contenuto letto → Voci → Italiano* e scarica una voce "Avanzata" o "Premium". Poi in Jarvis: ⚙︎ → **Voce** → scegli e premi **Prova voce**.

**Se il microfono dell'app non parte:** iOS è schizzinoso con il riconoscimento vocale nelle app aggiunte alla Home. Hai due alternative che funzionano sempre: il **microfono della tastiera** dell'iPhone (dettatura), oppure il **Comando Siri** del passo successivo, che è comunque il modo migliore per parlargli a mani libere.

**Se non senti la voce:** controlla il tasto laterale del silenzioso e il volume multimediale.

---

## 6. Attivazione a voce con Siri

Segui la guida: **[docs/SIRI.md](docs/SIRI.md)**. Alla fine dirai *"Ehi Siri, Jarvis"* e lui ti risponderà a voce. Lì trovi anche come lanciarlo con il doppio tocco sul retro dell'iPhone, dalla schermata di blocco o dal Centro di Controllo.

---

## 7. Personalizza Jarvis

Tutte le modifiche si fanno dal sito GitHub (matita ✏️ sul file → modifica → **Commit changes**). Dopo ~1 minuto Jarvis è aggiornato.

| Voglio… | Dove |
|---|---|
| Cambiare carattere, tono, cosa sa di me | `src/prompt.js` (sezione *Profilo*: scrivi città, lavoro, interessi) |
| Cambiare il mio nome / fuso orario | `wrangler.toml` → `OWNER_NAME`, `TIMEZONE` |
| Un altro modello gratuito (più leggero/veloce) | `wrangler.toml` → `MODEL` (es. `gemini-3.5-flash-lite`) |
| Risposte più rapide | `wrangler.toml` → togli il `#` da `THINKING_LEVEL = "low"` |
| Risposte più lunghe | `wrangler.toml` → `MAX_TOKENS` |
| Cambiare i colori dell'app | `public/style.css` (variabili `--cyan`, `--bg` in cima) |
| Aggiungere un nuovo potere | `src/tools.js` (vedi sotto) |

### Come aggiungere uno strumento
In `src/tools.js`: 1) aggiungi una descrizione in `TOOL_DEFINITIONS` (nome, a cosa serve, parametri); 2) aggiungi un `case` in `runTool()` che esegue l'azione e ritorna un testo. Gemini decide da solo quando usarlo in base alla descrizione. Esempi facili: leggere un altro feed RSS, chiamare un webhook (per accendere luci via Comandi/IFTTT/Home Assistant), interrogare un tuo foglio Google.

### Cosa sa fare, e cosa no
- ✅ Ora e data, meteo di una città, titoli delle notizie italiane, voci di Wikipedia, note (con la Fase 4), conversazione normale.
- ❌ Non ha la ricerca web libera di Google: sul piano gratuito non è disponibile. Per prezzi, risultati sportivi e dati "in diretta" Jarvis ti dirà onestamente che non può verificarli.
- ❌ Non può agire sull'iPhone (chiamate, messaggi, calendario) se non glielo aggiungi come strumento.

---

## 8. Fase 4: note persistenti (opzionale)

Con questa fase Jarvis ricorda cose tra una conversazione e l'altra ("Jarvis, ricordami che il codice del garage è…", "che appunti ho?").

1. **Cloudflare → Storage & Databases → KV → Create** → nome `jarvis-notes` → **Add**.
2. Copia l'**ID** del namespace appena creato.
3. Su GitHub apri `wrangler.toml` (✏️), togli il `#` dalle tre righe `[[kv_namespaces]]`, `binding`, `id` e incolla l'ID:
   ```toml
   [[kv_namespaces]]
   binding = "NOTES"
   id = "il-tuo-id-qui"
   ```
4. **Commit changes** → il deploy parte da solo → prova: *"Salva una nota: comprare il pane"*.

> Le note sono salvate nel tuo account Cloudflare, non su GitHub. Non scriverci password o dati sensibili.

---

## 9. Fase 5: briefing mattutino (opzionale)

Ogni mattina una notifica sull'iPhone con data, meteo e titoli delle notizie, preparata da Jarvis. Funziona con **GitHub Actions** (che chiama Jarvis) e **ntfy** (app gratuita per le notifiche push).

1. App Store → installa **ntfy**. Apri l'app → **+** → inventa un nome di *topic* lungo e impossibile da indovinare, ad esempio `jarvis-k8s2m9x4q7pz31` → iscriviti. *(Il topic funziona come una password: chi lo conosce può scriverti.)*
2. Su GitHub aggiungi altri 2 secret (come al passo 3):
   - `JARVIS_URL` = `https://jarvis.TUO-SUBDOMAIN.workers.dev` (senza `/` finale)
   - `NTFY_TOPIC` = il topic scelto
3. Apri `.github/workflows/briefing.yml`, modifica la richiesta `PROMPT` (la tua città, i tuoi interessi) e **togli il `#`** davanti a `schedule:` e `- cron:`.
   - L'orario è in **UTC**: `30 6 * * 1-5` = 06:30 UTC dal lunedì al venerdì = 07:30 in inverno, 08:30 in estate in Italia.
4. Prova subito: **Actions → Briefing mattutino → Run workflow** → dopo qualche secondo arriva la notifica.

GitHub può ritardare le esecuzioni programmate di qualche minuto: è normale.

---

## 10. Sicurezza, privacy e limiti

**Privacy del piano gratuito di Gemini (importante)**
- Sui servizi gratuiti Google dichiara di poter usare ciò che invii per migliorare i propri prodotti, e persone possono leggere alcune conversazioni. Per chi è nello Spazio Economico Europeo, in Regno Unito e Svizzera le fonti che ho letto indicano un trattamento dei dati più protettivo, ma **verifica i termini nella tua pagina di AI Studio**.
- Regola pratica: **non dire a Jarvis password, dati bancari, documenti, informazioni sanitarie o riservate.** Per tutto il resto (meteo, curiosità, promemoria banali) non c'è problema.
- Anche le note salvate con la Fase 4 vengono mandate a Gemini quando le leggi: tienile innocue.

**Sicurezza**
- La chiave Gemini vive solo nei secret di GitHub/Cloudflare, mai nel codice né nel telefono.
- Il repo è **privato**. Non committare mai chiavi (`.dev.vars` è già escluso dal `.gitignore`).
- Se pensi che il `JARVIS_TOKEN` sia finito in mani sbagliate: crea una nuova password → aggiorna il secret su GitHub → rilancia il deploy → aggiorna il token nell'app e nel Comando Siri.
- Se la chiave Gemini è compromessa: AI Studio → API keys → elimina e ricrea, poi aggiorna il secret e rilancia il deploy.

**Limiti e costi**
- Tutto gratis, finché **non attivi la fatturazione** su Google.
- Gemini ha una quota gratuita per progetto (richieste al minuto/giorno, si azzera a mezzanotte ora del Pacifico). Se la finisci vedrai un errore 429: aspetta e riprova.
- Google può cambiare modelli e quote gratuiti. Se un giorno il modello non risponde più (errore 404), apri AI Studio, guarda quali modelli sono gratuiti e cambia `MODEL` in `wrangler.toml`.
- Il backend limita già da sé la lunghezza di messaggi, storico e catene di strumenti.

---

## 11. Problemi comuni

| Sintomo | Causa probabile | Soluzione |
|---|---|---|
| L'Action fallisce con un errore su *workers.dev subdomain* | Non hai ancora scelto il sottodominio | Cloudflare → Workers & Pages → scegli il sottodominio → rilancia l'Action |
| L'Action fallisce con *Authentication error* / codice 10000 | Token Cloudflare con permessi mancanti o ID account sbagliato | Ricrea il token col modello *Edit Cloudflare Workers* e ricontrolla `CLOUDFLARE_ACCOUNT_ID` |
| L'Action fallisce al passo *Test* | Qualcosa di rotto nel codice dopo una modifica | Leggi il log: dice quale test e perché. Annulla l'ultima modifica |
| App: "Token non valido" | Token diverso da quello del secret `JARVIS_TOKEN` | Reincollalo in ⚙︎ (controlla spazi). Se hai cambiato il secret, rilancia il deploy |
| App: "Server non configurato" (500) | Mancano i secret su Cloudflare | Controlla i nomi dei secret su GitHub e rilancia il deploy |
| App: "Errore Gemini (403)" | Chiave Gemini errata o non valida | Ricrea la chiave in AI Studio, aggiorna il secret, rilancia il deploy |
| App: "Errore Gemini (404)" | Modello non più disponibile | Cambia `MODEL` in `wrangler.toml` con un modello gratuito attuale |
| App: "Errore Gemini (400)" | Impostazione non accettata dal modello | Se hai attivato `THINKING_LEVEL`, rimettilo come commento |
| App: "Errore Gemini (429)" | Quota gratuita esaurita | Aspetta qualche minuto (o fino al giorno dopo) |
| Non sento la voce | Silenzioso / volume / voce non sbloccata | Controlla il tasto silenzioso, alza il volume, prova ⚙︎ → *Prova voce* |
| Il microfono non parte | Limite di iOS sulle app dalla Home | Usa la dettatura della tastiera o il Comando Siri |
| Vedo ancora la versione vecchia | Cache | Chiudi l'app dal selettore e riaprila |
| La conversazione "impazzisce" | Storico lungo | 🗑 in alto per cancellare la chat |

Per un test dal terminale (opzionale):
```bash
curl -X POST https://jarvis.TUO-SUBDOMAIN.workers.dev/api/chat \
  -H "Authorization: Bearer IL_TUO_TOKEN" -H "Content-Type: application/json" \
  -d '{"message":"Che ore sono?"}'
```

---

## 12. Idee per andare oltre

- **Streaming** delle risposte (parole che compaiono mentre arrivano).
- **Memoria a lungo termine**: far riassumere a Jarvis chi sei e salvarlo nel KV, ricaricandolo nel prompt.
- **Domotica**: uno strumento che chiama un webhook di Home Assistant o un Comando Rapido via URL.
- **Calendario e email**: collegare le API di Google o Microsoft come strumenti.
- **Voce più realistica**: sostituire la sintesi del browser con un servizio di text-to-speech via API.
- **Più persone**: un token per ciascuno e limiti di utilizzo (Cloudflare Rate Limiting).

Una nota onesta: una parola di attivazione "Hey Jarvis" sempre in ascolto non è possibile in una web app su iPhone; per quello c'è Siri col Comando Rapido. Un'app nativa iOS (Xcode) potrebbe fare di più, ma richiede un Mac e molto più lavoro.

---

## 13. Mappa dei file

```
jarvis/
├── README.md                    ← questa guida
├── docs/SIRI.md                 ← guida al Comando Rapido "Ehi Siri, Jarvis"
├── wrangler.toml                ← configurazione (modello, nome, fuso orario, KV)
├── package.json
├── src/
│   ├── index.js                 ← il server: sicurezza, chiamata a Gemini, ciclo degli strumenti
│   ├── prompt.js                ← la personalità di Jarvis
│   └── tools.js                 ← gli strumenti (ora, meteo, notizie, Wikipedia, note)
├── public/                      ← l'app per iPhone (PWA)
│   ├── index.html · style.css · app.js
│   ├── sw.js · manifest.webmanifest
│   └── icons/
├── test/worker.test.mjs         ← 20 test automatici (npm test)
├── .github/workflows/
│   ├── deploy.yml               ← deploy automatico a ogni push
│   └── briefing.yml             ← briefing mattutino (opzionale)
├── .gitignore
└── .dev.vars.example            ← per provare in locale (solo da computer)
```

Buon divertimento, Boss. 🛰️
