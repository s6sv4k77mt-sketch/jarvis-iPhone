# "Ehi Siri, Jarvis": attivare Jarvis a voce

Una web app (PWA) su iPhone **non può** restare in ascolto di una parola di attivazione. Il modo giusto per chiamare Jarvis a mani libere è un **Comando Rapido** (app *Comandi*), che Siri sa lanciare a voce.

Tempo: 5 minuti. I nomi delle azioni possono cambiare leggermente tra versioni di iOS.

## 1. Crea il comando

App **Comandi** → scheda **Comandi** → **+** (in alto a destra). Aggiungi queste 4 azioni, in ordine:

**Azione 1 – "Detta testo"**
- Lingua: **Italiano**
- Interrompi l'ascolto: **Dopo una pausa**

**Azione 2 – "Ottieni contenuti dall'URL"**
- URL: `https://jarvis.TUO-SUBDOMAIN.workers.dev/api/chat`
- Tocca la freccia **Mostra altro** e imposta:
  - Metodo: **POST**
  - Intestazioni (aggiungi due righe):
    - `Authorization` = `Bearer IL_TUO_JARVIS_TOKEN` (con uno spazio dopo "Bearer")
    - `Content-Type` = `application/json`
  - Corpo della richiesta: **JSON**
    - Aggiungi un campo di tipo **Testo**
    - Chiave: `message`
    - Valore: tocca il campo e scegli la variabile **Testo dettato** (quella dell'azione 1)

**Azione 3 – "Ottieni valore del dizionario"**
- Ottieni: **Valore** per la chiave `reply`
- Dal dizionario: **Contenuti dell'URL** (azione 2)

**Azione 4 – "Pronuncia testo"**
- Testo: **Valore del dizionario** (azione 3)

## 2. Dagli il nome

Tocca il nome in alto e chiamalo **Jarvis** (o "Chiedi a Jarvis"). Il nome è la frase che dirai a Siri.

## 3. Provalo

- Dì: **"Ehi Siri, Jarvis"** → Siri ti ascolta → parla → Jarvis risponde a voce.
- Se non parte, controlla in *Impostazioni → Siri* che "Ehi Siri" sia attivo.

## 4. Altri modi di lanciarlo (scegli quello che preferisci)

| Modo | Dove si imposta |
|---|---|
| **Tocco posteriore** (doppio/triplo tocco sul retro dell'iPhone) | Impostazioni → Accessibilità → Tocco → Tocco posteriore → scegli il comando "Jarvis" |
| **Tasto Azione** (solo iPhone 15 **Pro**/Pro Max, non sul 15 normale) | Impostazioni → Tasto Azione → Comando rapido → Jarvis |
| **Schermata di blocco / Centro di Controllo** | Tieni premuto sulla schermata di blocco → Personalizza → aggiungi il controllo di un Comando; oppure Centro di Controllo → + → Aggiungi un controllo |
| **Widget in Home** | Tieni premuto sulla Home → + → Comandi → scegli il widget |

## Limiti da sapere

- Ogni chiamata dal Comando è una **domanda singola**: Jarvis non ricorda cosa ti ha detto 5 minuti fa. (L'app PWA invece mantiene la conversazione.)
- Il Comando usa la voce di Siri per leggere la risposta, non la voce scelta nell'app.
- Il token sta scritto dentro il Comando: non condividere il Comando con nessuno.

## Variante: conversazione che continua

Per farlo "ripetere" finché non dici basta: avvolgi le azioni 1-4 in un blocco **Ripeti** (es. 5 volte). Per uscire, interrompi il comando. Più semplice però è usare l'app PWA in "Conversazione continua".
