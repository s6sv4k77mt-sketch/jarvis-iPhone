// =====================================================================
//  GLI "STRUMENTI" DI JARVIS
//  Sono funzioni che Gemini può decidere di chiamare quando servono.
//  Per aggiungerne uno: 1) descrivilo in TOOL_DEFINITIONS
//                       2) implementalo in runTool()
// =====================================================================

export const TOOL_DEFINITIONS = [
  {
    name: "get_current_time",
    description:
      "Restituisce data e ora attuali. Usalo quando serve sapere che ore sono o che giorno è, anche in un altro fuso orario.",
    input_schema: {
      type: "object",
      properties: {
        timezone: {
          type: "string",
          description:
            "Fuso orario IANA, ad esempio Europe/Rome o America/New_York. Se omesso usa quello dell'utente.",
        },
      },
      required: [],
    },
  },
  {
    name: "get_weather",
    description:
      "Restituisce il meteo attuale e le previsioni dei prossimi giorni per una città.",
    input_schema: {
      type: "object",
      properties: {
        city: { type: "string", description: "Nome della città, ad esempio Milano" },
        days: {
          type: "integer",
          description: "Giorni di previsione da 1 a 7 (default 2)",
          minimum: 1,
          maximum: 7,
        },
      },
      required: ["city"],
    },
  },
  {
    name: "get_news",
    description:
      "Restituisce i titoli delle notizie più recenti in Italia (da Google Notizie), generali oppure su un argomento. Fornisce solo i titoli, non gli articoli.",
    input_schema: {
      type: "object",
      properties: {
        topic: {
          type: "string",
          description: "Argomento facoltativo, ad esempio 'calcio' o 'economia'. Se omesso: notizie principali.",
        },
      },
      required: [],
    },
  },
  {
    name: "wikipedia_summary",
    description:
      "Cerca su Wikipedia in italiano e restituisce l'introduzione della voce più pertinente. Utile per spiegare persone, luoghi, eventi e concetti.",
    input_schema: {
      type: "object",
      properties: { query: { type: "string", description: "Cosa cercare, ad esempio 'Galileo Galilei'" } },
      required: ["query"],
    },
  },
  {
    name: "save_note",
    description:
      "Salva una nota o un promemoria testuale per l'utente. Usalo quando l'utente chiede di ricordare, annotare o salvare qualcosa.",
    input_schema: {
      type: "object",
      properties: { text: { type: "string", description: "Il testo della nota" } },
      required: ["text"],
    },
  },
  {
    name: "list_notes",
    description: "Elenca le note salvate dall'utente, con il loro identificativo.",
    input_schema: { type: "object", properties: {}, required: [] },
  },
  {
    name: "delete_note",
    description: "Cancella una nota tramite il suo identificativo (preso da list_notes).",
    input_schema: {
      type: "object",
      properties: { id: { type: "string", description: "Identificativo della nota" } },
      required: ["id"],
    },
  },
];

const NOTE_TOOLS = new Set(["save_note", "list_notes", "delete_note"]);

/** Strumenti disponibili in base alla configurazione (le note servono il KV). */
export function availableTools(env) {
  return TOOL_DEFINITIONS.filter((t) => !NOTE_TOOLS.has(t.name) || env.NOTES);
}

/** Esegue uno strumento. Ritorna { content: string, isError: boolean }. */
export async function runTool(name, input = {}, env = {}) {
  try {
    switch (name) {
      case "get_current_time":
        return ok(getCurrentTime(input.timezone, env));
      case "get_weather":
        return ok(await getWeather(input.city, input.days));
      case "get_news":
        return ok(await getNews(input.topic));
      case "wikipedia_summary":
        return ok(await wikipediaSummary(input.query));
      case "save_note":
        return ok(await saveNote(input.text, env));
      case "list_notes":
        return ok(await listNotes(env));
      case "delete_note":
        return ok(await deleteNote(input.id, env));
      default:
        return fail(`Strumento sconosciuto: ${name}`);
    }
  } catch (e) {
    return fail(`Errore nello strumento ${name}: ${e.message}`);
  }
}

const ok = (content) => ({ content, isError: false });
const fail = (content) => ({ content, isError: true });

// ---------------------------------------------------------------- ora
function getCurrentTime(timezone, env) {
  const tz = timezone || env.TIMEZONE || "Europe/Rome";
  try {
    const text = new Intl.DateTimeFormat("it-IT", {
      dateStyle: "full",
      timeStyle: "medium",
      timeZone: tz,
    }).format(new Date());
    return `${text} (${tz})`;
  } catch {
    throw new Error(`Fuso orario non valido: ${tz}`);
  }
}

// -------------------------------------------------------------- meteo
const WEATHER_CODES = {
  0: "sereno",
  1: "prevalentemente sereno",
  2: "parzialmente nuvoloso",
  3: "coperto",
  45: "nebbia",
  48: "nebbia con brina",
  51: "pioggerella leggera",
  53: "pioggerella",
  55: "pioggerella intensa",
  56: "pioggerella gelata",
  57: "pioggerella gelata intensa",
  61: "pioggia leggera",
  63: "pioggia",
  65: "pioggia forte",
  66: "pioggia gelata",
  67: "pioggia gelata forte",
  71: "neve leggera",
  73: "neve",
  75: "neve forte",
  77: "granelli di neve",
  80: "rovesci leggeri",
  81: "rovesci",
  82: "rovesci violenti",
  85: "rovesci di neve",
  86: "rovesci di neve forti",
  95: "temporale",
  96: "temporale con grandine",
  99: "temporale con grandine forte",
};
const describeCode = (c) => WEATHER_CODES[c] ?? "condizioni variabili";

async function getWeather(city, days = 2) {
  if (!city || typeof city !== "string") throw new Error("Città mancante");
  const n = Math.min(Math.max(parseInt(days, 10) || 2, 1), 7);

  const geoUrl =
    "https://geocoding-api.open-meteo.com/v1/search?count=1&language=it&format=json&name=" +
    encodeURIComponent(city);
  const geo = await (await fetchOrThrow(geoUrl, "Servizio meteo")).json();
  const place = geo.results?.[0];
  if (!place) throw new Error(`Città non trovata: ${city}`);

  const wxUrl =
    "https://api.open-meteo.com/v1/forecast" +
    `?latitude=${place.latitude}&longitude=${place.longitude}` +
    "&current=temperature_2m,apparent_temperature,relative_humidity_2m,weather_code,wind_speed_10m" +
    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
    `&timezone=auto&forecast_days=${n}`;
  const wx = await (await fetchOrThrow(wxUrl, "Servizio meteo")).json();

  const c = wx.current;
  const lines = [
    `Meteo a ${place.name}${place.country ? ` (${place.country})` : ""}:`,
    `Adesso: ${describeCode(c.weather_code)}, ${Math.round(c.temperature_2m)} gradi (percepiti ${Math.round(c.apparent_temperature)}), umidità ${c.relative_humidity_2m}%, vento ${Math.round(c.wind_speed_10m)} km/h.`,
  ];
  const d = wx.daily;
  for (let i = 0; i < d.time.length; i++) {
    lines.push(
      `${d.time[i]}: ${describeCode(d.weather_code[i])}, minima ${Math.round(d.temperature_2m_min[i])}, massima ${Math.round(d.temperature_2m_max[i])}, probabilità di pioggia ${d.precipitation_probability_max[i] ?? "n.d."}%.`
    );
  }
  return lines.join("\n");
}

async function fetchOrThrow(url, label = "Servizio esterno", init = {}) {
  const res = await fetch(url, init);
  if (!res.ok) throw new Error(`${label} non raggiungibile (${res.status})`);
  return res;
}

// ------------------------------------------------------------ notizie
function decodeXml(s) {
  return s
    .replace(/^<!\[CDATA\[([\s\S]*?)\]\]>$/, "$1")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .replace(/&amp;/g, "&") // sempre per ultimo
    .trim();
}

async function getNews(topic) {
  const base = topic
    ? `https://news.google.com/rss/search?q=${encodeURIComponent(String(topic).slice(0, 100))}&`
    : "https://news.google.com/rss?";
  const xml = await (await fetchOrThrow(`${base}hl=it&gl=IT&ceid=IT:it`, "Google Notizie")).text();

  const titles = [...xml.matchAll(/<item>([\s\S]*?)<\/item>/g)]
    .slice(0, 6)
    .map((m) => decodeXml((m[1].match(/<title>([\s\S]*?)<\/title>/) || [])[1] || ""))
    .filter(Boolean);

  if (!titles.length) return "Nessuna notizia trovata.";
  return "Titoli di Google Notizie:\n" + titles.map((t, i) => `${i + 1}. ${t}`).join("\n");
}

// ---------------------------------------------------------- wikipedia
async function wikipediaSummary(query) {
  if (!query || typeof query !== "string") throw new Error("Cosa devo cercare?");
  const url =
    "https://it.wikipedia.org/w/api.php?action=query&format=json&generator=search&gsrlimit=1" +
    "&prop=extracts&exintro=1&explaintext=1&exchars=1200&gsrsearch=" +
    encodeURIComponent(query.slice(0, 200));
  const data = await (
    await fetchOrThrow(url, "Wikipedia", { headers: { "user-agent": "JarvisPersonalAssistant/1.0" } })
  ).json();
  const page = Object.values(data.query?.pages || {})[0];
  if (!page?.extract) throw new Error(`Nessuna voce trovata per: ${query}`);
  return `${page.title}: ${page.extract}`;
}

// --------------------------------------------------------------- note
function requireKV(env) {
  if (!env.NOTES) throw new Error("Le note non sono configurate (manca il KV NOTES).");
  return env.NOTES;
}

async function saveNote(text, env) {
  const kv = requireKV(env);
  if (!text || typeof text !== "string") throw new Error("Testo della nota mancante");
  const id = crypto.randomUUID().slice(0, 8);
  await kv.put(
    `note:${id}`,
    JSON.stringify({ text: text.slice(0, 2000), created: new Date().toISOString() })
  );
  return `Nota salvata con id ${id}.`;
}

async function listNotes(env) {
  const kv = requireKV(env);
  const { keys } = await kv.list({ prefix: "note:", limit: 50 });
  if (!keys.length) return "Non ci sono note salvate.";
  const items = await Promise.all(
    keys.map(async (k) => {
      const v = JSON.parse((await kv.get(k.name)) || "{}");
      return { id: k.name.slice(5), ...v };
    })
  );
  items.sort((a, b) => (a.created || "").localeCompare(b.created || ""));
  return items.map((n) => `[${n.id}] ${n.text}`).join("\n");
}

async function deleteNote(id, env) {
  const kv = requireKV(env);
  if (!id || typeof id !== "string") throw new Error("Id mancante");
  await kv.delete(`note:${id}`);
  return `Nota ${id} cancellata.`;
}
