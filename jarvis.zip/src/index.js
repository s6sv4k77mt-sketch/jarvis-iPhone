// =====================================================================
//  JARVIS - backend (Cloudflare Worker) con Google Gemini
//
//  POST /api/chat   { "message": "ciao" }
//               oppure { "messages": [{ "role": "user", "content": "ciao" }, ...] }
//     Header:  Authorization: Bearer <JARVIS_TOKEN>
//     Risposta: { "reply": "testo di Jarvis" }
//
//  GET  /api/health  -> { ok: true }
//
//  Tutto il resto (/, /app.js, ...) è servito dalla cartella public/.
// =====================================================================

import { buildSystemPrompt } from "./prompt.js";
import { availableTools, runTool } from "./tools.js";

const GEMINI_BASE = "https://generativelanguage.googleapis.com/v1beta/models";
const DEFAULT_MODEL = "gemini-3.8-flash";
const MAX_TOOL_ROUNDS = 6; // quante volte Gemini può chiamare strumenti per una risposta
const MAX_HISTORY = 30; // quanti messaggi di storico accettiamo
const MAX_MESSAGE_CHARS = 4000; // lunghezza massima di un singolo messaggio

const json = (data, status = 200) =>
  new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === "/api/health") return json({ ok: true });

    if (url.pathname === "/api/chat") {
      if (request.method !== "POST") return json({ error: "Metodo non consentito" }, 405);

      if (!env.JARVIS_TOKEN || !env.GEMINI_API_KEY) {
        return json(
          { error: "Server non configurato: mancano i secret JARVIS_TOKEN o GEMINI_API_KEY." },
          500
        );
      }
      if (!isAuthorized(request, env)) return json({ error: "Non autorizzato" }, 401);

      try {
        return await handleChat(request, env);
      } catch (e) {
        console.error("Errore /api/chat:", e);
        return json({ error: `Errore interno: ${e.message || "sconosciuto"}` }, 500);
      }
    }

    return json({ error: "Non trovato" }, 404);
  },
};

// ------------------------------------------------------------ sicurezza
function isAuthorized(request, env) {
  const header = request.headers.get("authorization") || "";
  const match = header.match(/^Bearer\s+(.+)$/i);
  if (!match) return false;
  return safeEqual(match[1].trim(), env.JARVIS_TOKEN);
}

/** Confronto a tempo costante, per non rivelare il token "a tentativi". */
function safeEqual(a, b) {
  const enc = new TextEncoder();
  const x = enc.encode(a);
  const y = enc.encode(b);
  let diff = x.length ^ y.length;
  const len = Math.max(x.length, y.length);
  for (let i = 0; i < len; i++) diff |= (x[i] ?? 0) ^ (y[i] ?? 0);
  return diff === 0;
}

// ----------------------------------------------------------------- chat
function normalizeMessages(body) {
  let list = [];
  if (typeof body?.message === "string") {
    list = [{ role: "user", content: body.message }];
  } else if (Array.isArray(body?.messages)) {
    list = body.messages;
  }

  const clean = list
    .filter(
      (m) =>
        m &&
        (m.role === "user" || m.role === "assistant") &&
        typeof m.content === "string" &&
        m.content.trim()
    )
    .map((m) => ({ role: m.role, content: m.content.trim().slice(0, MAX_MESSAGE_CHARS) }))
    .slice(-MAX_HISTORY);

  while (clean.length && clean[0].role !== "user") clean.shift();
  if (!clean.length || clean[clean.length - 1].role !== "user") return null;
  return clean;
}

/** Il formato di Gemini: "assistant" si chiama "model" e il testo sta dentro "parts". */
function toGeminiContents(messages) {
  return messages.map((m) => ({
    role: m.role === "assistant" ? "model" : "user",
    parts: [{ text: m.content }],
  }));
}

/** Gemini accetta solo un sottoinsieme di JSON Schema: togliamo ciò che dà problemi. */
function cleanSchema(schema) {
  const out = { ...schema };
  if (Array.isArray(out.required) && out.required.length === 0) delete out.required;
  return out;
}

function buildTools(env) {
  const declarations = availableTools(env).map(({ name, description, input_schema }) => {
    const decl = { name, description };
    // Gemini rifiuta "parameters" con "properties" vuote: per gli strumenti senza parametri si omette.
    if (input_schema?.properties && Object.keys(input_schema.properties).length > 0) {
      decl.parameters = cleanSchema(input_schema);
    }
    return decl;
  });
  return [{ functionDeclarations: declarations }];
}

function generationConfig(env) {
  const config = { maxOutputTokens: parseInt(env.MAX_TOKENS, 10) || 2048 };
  // Facoltativo: "low" rende le risposte più rapide (vedi wrangler.toml).
  if (env.THINKING_LEVEL) config.thinkingConfig = { thinkingLevel: String(env.THINKING_LEVEL) };
  return config;
}

async function callGemini(env, system, contents, tools) {
  const model = encodeURIComponent(env.MODEL || DEFAULT_MODEL);
  return fetch(`${GEMINI_BASE}/${model}:generateContent`, {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-goog-api-key": env.GEMINI_API_KEY, // nell'header, mai nell'URL
    },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: system }] },
      contents,
      tools,
      generationConfig: generationConfig(env),
    }),
  });
}

async function describeApiError(res) {
  const raw = (await res.text()).slice(0, 2000);
  let message = raw;
  try {
    message = JSON.parse(raw)?.error?.message || raw;
  } catch {}
  message = String(message).replace(/\s+/g, " ").slice(0, 200);

  let hint = "";
  if (res.status === 429) hint = "Hai finito la quota gratuita del momento: riprova tra un po'.";
  else if (res.status === 403) hint = "Chiave non valida o non abilitata: ricontrolla GEMINI_API_KEY.";
  else if (res.status === 404) hint = "Modello non trovato: controlla MODEL in wrangler.toml.";
  else if (res.status === 400) hint = "Richiesta rifiutata: controlla MODEL e THINKING_LEVEL in wrangler.toml.";
  else if (res.status >= 500) hint = "Gemini è momentaneamente in difficoltà: riprova.";

  return `Errore Gemini (${res.status}). ${hint} ${message}`.replace(/\s+/g, " ").trim();
}

async function handleChat(request, env) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "JSON non valido" }, 400);
  }

  const messages = normalizeMessages(body);
  if (!messages) return json({ error: "Serve almeno un messaggio utente non vuoto." }, 400);

  const system = buildSystemPrompt(env);
  const tools = buildTools(env);
  const contents = toGeminiContents(messages);

  for (let round = 0; round < MAX_TOOL_ROUNDS; round++) {
    const res = await callGemini(env, system, contents, tools);

    if (!res.ok) {
      const error = await describeApiError(res);
      console.error(error);
      return json({ error }, 502);
    }

    const data = await res.json();
    const candidate = data.candidates?.[0];

    if (!candidate) {
      const reason = data.promptFeedback?.blockReason;
      return json({
        reply: reason
          ? "Questa richiesta è stata bloccata dai filtri di sicurezza, non posso rispondere."
          : "Non ho ricevuto nessuna risposta, riprova.",
      });
    }

    const parts = candidate.content?.parts ?? [];
    const calls = parts.filter((p) => p.functionCall);

    if (calls.length > 0) {
      // Rimandiamo a Gemini il suo messaggio ESATTAMENTE com'è (contiene firme interne
      // necessarie ai modelli recenti), poi aggiungiamo i risultati degli strumenti.
      contents.push({ role: "model", parts });

      const responses = [];
      for (const part of calls) {
        const { name, args, id } = part.functionCall;
        const out = await runTool(name, args || {}, env);
        responses.push({
          functionResponse: {
            ...(id ? { id } : {}),
            name,
            response: out.isError ? { error: out.content } : { result: out.content },
          },
        });
      }
      contents.push({ role: "user", parts: responses });
      continue;
    }

    const reply = parts
      .filter((p) => typeof p.text === "string" && !p.thought)
      .map((p) => p.text)
      .join("")
      .trim();

    if (!reply) {
      const why = candidate.finishReason ? ` (${candidate.finishReason})` : "";
      return json({ reply: `Non sono riuscito a formulare una risposta${why}. Riprova.` });
    }
    return json({ reply });
  }

  return json({ reply: "Ho fatto troppi passaggi senza arrivare a una risposta. Riprova, magari più semplice." });
}
