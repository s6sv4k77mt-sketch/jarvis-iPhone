// =====================================================================
//  JARVIS - app per iPhone (PWA)
//  Chat testuale + voce (microfono e sintesi vocale del browser)
// =====================================================================
(() => {
  "use strict";

  const K = {
    token: "jarvis.token",
    speak: "jarvis.speak",
    loop: "jarvis.loop",
    voice: "jarvis.voice",
    history: "jarvis.history",
  };
  const MAX_SAVED = 40;

  const $ = (id) => document.getElementById(id);
  const log = $("log");
  const input = $("input");
  const form = $("form");
  const micBtn = $("micBtn");
  const dot = $("statusDot");
  const hint = $("hint");
  const settings = $("settings");

  // ------------------------------------------------------ storage sicuro
  const store = {
    get(k, fallback = null) {
      try {
        const v = localStorage.getItem(k);
        return v === null ? fallback : v;
      } catch {
        return fallback;
      }
    },
    set(k, v) {
      try {
        localStorage.setItem(k, v);
      } catch {}
    },
    del(k) {
      try {
        localStorage.removeItem(k);
      } catch {}
    },
  };

  let history = [];
  try {
    history = JSON.parse(store.get(K.history, "[]")) || [];
  } catch {
    history = [];
  }
  const saveHistory = () => store.set(K.history, JSON.stringify(history.slice(-MAX_SAVED)));

  let busy = false;

  // ------------------------------------------------------------- UI base
  function setStatus(state) {
    dot.className = "dot" + (state ? " " + state : "");
  }

  function showHint(text) {
    if (!text) {
      hint.hidden = true;
      return;
    }
    hint.textContent = text;
    hint.hidden = false;
  }

  function addMessage(role, text, extraClass = "") {
    const el = document.createElement("div");
    el.className = `msg ${role} ${extraClass}`.trim();
    el.textContent = text; // textContent: mai innerHTML, così nessun rischio XSS
    log.appendChild(el);
    log.scrollTop = log.scrollHeight;
    return el;
  }

  function renderHistory() {
    log.textContent = "";
    if (!history.length) {
      addMessage("assistant", "Sistemi operativi. Come posso esserti utile?");
    }
    for (const m of history) addMessage(m.role, m.content);
  }

  // --------------------------------------------------------------- voce
  const synth = "speechSynthesis" in window ? window.speechSynthesis : null;
  let audioUnlocked = false;

  /** iOS permette di parlare solo dopo un gesto dell'utente: "sblocchiamo" al primo tocco. */
  function unlockAudio() {
    if (!synth || audioUnlocked) return;
    try {
      const u = new SpeechSynthesisUtterance(" ");
      u.volume = 0;
      synth.speak(u);
      audioUnlocked = true;
    } catch {}
  }

  function cleanForSpeech(text) {
    return text
      .replace(/```[\s\S]*?```/g, " ")
      .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
      .replace(/https?:\/\/\S+/g, " ")
      .replace(/[*_#`>~|]/g, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function pickVoice() {
    if (!synth) return null;
    const voices = synth.getVoices().filter((v) => v.lang && v.lang.toLowerCase().startsWith("it"));
    const saved = store.get(K.voice);
    return voices.find((v) => v.voiceURI === saved) || voices[0] || null;
  }

  function speak(text) {
    return new Promise((resolve) => {
      if (!synth) return resolve();
      const clean = cleanForSpeech(text);
      if (!clean) return resolve();
      synth.cancel();
      const u = new SpeechSynthesisUtterance(clean);
      u.lang = "it-IT";
      const v = pickVoice();
      if (v) u.voice = v;
      u.rate = 1.02;
      u.onstart = () => setStatus("speaking");
      u.onend = u.onerror = () => {
        setStatus("");
        resolve();
      };
      synth.speak(u);
    });
  }

  function stopSpeaking() {
    if (synth) synth.cancel();
  }

  function populateVoices() {
    if (!synth) return;
    const sel = $("voiceSelect");
    const voices = synth.getVoices().filter((v) => v.lang && v.lang.toLowerCase().startsWith("it"));
    sel.textContent = "";
    if (!voices.length) {
      const o = document.createElement("option");
      o.textContent = "Nessuna voce italiana trovata";
      sel.appendChild(o);
      return;
    }
    const saved = store.get(K.voice);
    for (const v of voices) {
      const o = document.createElement("option");
      o.value = v.voiceURI;
      o.textContent = `${v.name} (${v.lang})`;
      if (v.voiceURI === saved) o.selected = true;
      sel.appendChild(o);
    }
  }
  if (synth) {
    populateVoices();
    synth.onvoiceschanged = populateVoices;
  }

  // ----------------------------------------------------- riconoscimento
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  let recognition = null;
  let listening = false;
  let transcript = "";

  function setListening(on) {
    listening = on;
    micBtn.classList.toggle("active", on);
    if (on) setStatus("listening");
    else if (!busy) setStatus("");
  }

  function startListening() {
    if (!SR || listening || busy) return;
    stopSpeaking();
    transcript = "";
    recognition = new SR();
    recognition.lang = "it-IT";
    recognition.interimResults = true;
    recognition.continuous = false;

    recognition.onresult = (e) => {
      let text = "";
      for (let i = 0; i < e.results.length; i++) text += e.results[i][0].transcript;
      transcript = text;
      input.value = text;
    };
    recognition.onerror = (e) => {
      if (e.error === "not-allowed" || e.error === "service-not-allowed") {
        showHint(
          "Microfono non consentito. Vai in Impostazioni > Safari > Microfono (e Dettatura attiva), " +
            "oppure usa il microfono della tastiera dell'iPhone."
        );
      } else if (e.error !== "no-speech" && e.error !== "aborted") {
        showHint("Errore del riconoscimento vocale (" + e.error + "). Puoi usare la dettatura della tastiera.");
      }
    };
    recognition.onend = () => {
      setListening(false);
      const t = transcript.trim();
      if (t) {
        input.value = "";
        send(t);
      }
    };

    try {
      recognition.start();
      setListening(true);
      showHint("");
    } catch {
      setListening(false);
    }
  }

  function stopListening() {
    if (recognition && listening) {
      try {
        recognition.stop();
      } catch {}
    }
  }

  // ------------------------------------------------------------- invio
  function openSettings() {
    $("tokenInput").value = store.get(K.token, "");
    $("speakToggle").checked = store.get(K.speak, "1") === "1";
    $("loopToggle").checked = store.get(K.loop, "0") === "1";
    populateVoices();
    if (!settings.open) settings.showModal();
  }

  async function send(text) {
    if (busy) return;
    const token = store.get(K.token);
    if (!token) {
      showHint("Prima inserisci il token di accesso nelle impostazioni (⚙︎).");
      openSettings();
      return;
    }

    unlockAudio();
    stopSpeaking();

    addMessage("user", text);
    history.push({ role: "user", content: text });
    saveHistory();

    busy = true;
    setStatus("thinking");
    const pending = addMessage("assistant", "…", "thinking");
    let reply = null;

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: "Bearer " + token },
        body: JSON.stringify({ messages: history.slice(-20) }),
      });
      let data = {};
      try {
        data = await res.json();
      } catch {}

      if (res.status === 401) {
        pending.remove();
        history.pop();
        saveHistory();
        addMessage("error", "Token non valido. Controllalo nelle impostazioni.");
        openSettings();
        return;
      }
      if (!res.ok) throw new Error(data.error || "Errore " + res.status);

      reply = data.reply || "…";
      pending.remove();
      addMessage("assistant", reply);
      history.push({ role: "assistant", content: reply });
      saveHistory();
    } catch (err) {
      pending.remove();
      history.pop(); // togliamo la domanda rimasta senza risposta
      saveHistory();
      addMessage("error", "Non riesco a contattare Jarvis: " + (err.message || err));
    } finally {
      busy = false;
      setStatus("");
    }

    if (reply && store.get(K.speak, "1") === "1") {
      await speak(reply);
      if (store.get(K.loop, "0") === "1" && SR) startListening();
    }
  }

  // ------------------------------------------------------------ eventi
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const t = input.value.trim();
    if (!t) return;
    input.value = "";
    send(t);
  });

  micBtn.addEventListener("click", () => {
    unlockAudio();
    if (!SR) {
      showHint("Qui il riconoscimento vocale non è disponibile: usa il microfono sulla tastiera dell'iPhone.");
      input.focus();
      return;
    }
    if (listening) stopListening();
    else startListening();
  });

  $("settingsBtn").addEventListener("click", openSettings);

  $("clearBtn").addEventListener("click", () => {
    if (!confirm("Cancellare tutta la conversazione?")) return;
    history = [];
    store.del(K.history);
    renderHistory();
  });

  $("testVoiceBtn").addEventListener("click", () => {
    store.set(K.voice, $("voiceSelect").value);
    unlockAudio();
    speak("Sistemi operativi. Sono a tua disposizione.");
  });

  $("settingsForm").addEventListener("submit", () => {
    store.set(K.token, $("tokenInput").value.trim());
    store.set(K.speak, $("speakToggle").checked ? "1" : "0");
    store.set(K.loop, $("loopToggle").checked ? "1" : "0");
    if ($("voiceSelect").value) store.set(K.voice, $("voiceSelect").value);
    showHint("");
  });

  // --------------------------------------------------------------- avvio
  renderHistory();
  if (!store.get(K.token)) {
    showHint("Benvenuto. Apri le impostazioni (⚙︎) e inserisci il tuo token di accesso per iniziare.");
  } else if (!SR) {
    showHint("Microfono dell'app non disponibile: usa il microfono sulla tastiera dell'iPhone per dettare.");
  }

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("/sw.js").catch(() => {});
  }
})();
